 function myAccInfo() {
    // Show account details, hide order details
    document.getElementById('accountSection').style.display = 'block';
    document.getElementById('myOrderSection').style.display = 'none';
}

 function MyOrders() {
    // Hide account details, show order details
    document.getElementById('accountSection').style.display = 'none';
    document.getElementById('myOrderSection').style.display = 'block';
 }

    // Simple stubs so clicking other buttons doesn't cause errors
    function ShopCart() { console.log("Shopping Cart clicked"); }
    function SignOut() { console.log("Sign Out clicked"); }
    function openSidebar(){ console.log ("Sidebar Opened");}
    function openCart() { console.log("Cart opened"); }

const accountForm = document.getElementById('accountForm');

//2. Form Validation.
 // Set it so that this function activates whenever user clicks submit
    accountForm.addEventListener('submit', saveProfileInfo)

    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    function saveProfileInfo(event) {
    event.preventDefault();

    const usernameValue = document.getElementById('username').value;
    const emailValue = document.getElementById('email').value;

    if (usernameValue === "" || emailValue === "") {
        alert("Error: Username and Email fields cannot be blank!");
        return; 
    }

    // 1. THE STORAGE UPGRADE: Lock these strings into local storage
    localStorage.setItem('savedUsername', usernameValue);
    localStorage.setItem('savedEmail', emailValue);

    // 2. Update the UI text
    const greetingHeader = document.getElementById('dashboardGreeting');
    greetingHeader.textContent = "Welcome back, " + usernameValue + "!";

    alert("Profile info saved securely for " + usernameValue);
}

function openCart() {
    displayCartItems();
    document.getElementById('cartSidebar').classList.add('open');
}
    
function displayCartItems() {
    const cartDiv = document.getElementById('cartItems');
    const totalDiv = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartDiv.innerHTML = '<p style="text-align:center;">Your cart is empty</p>';
        totalDiv.innerHTML = '';
        return;
    }
    
    let total = 0;
    cartDiv.innerHTML = cart.map((item, index) => {
        const subtotal = item.price * item.quantity;
        total += subtotal;
        return `
            <div class="cart-item">
                <div>
                    <strong>${item.name}</strong><br>
                    $${item.price} x ${item.quantity}
                </div>
                <div>
                    $${subtotal}
                    <button onclick="removeFromCart(${index})" style="background:#e2312b; color:white; border:none; padding:5px 10px; margin-left:10px; cursor:pointer;">×</button>
                </div>
            </div>
        `;
    }).join('');
    
    totalDiv.innerHTML = `Total: $${total.toLocaleString()}`;
}

function closeCart() {
    document.getElementById('cartSidebar').classList.remove('open');
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    displayCartItems();
}

function checkout() {
    if (cart.length === 0) {
        alert('Cart is empty!');
        return;
    }
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    alert(`Order placed! Total: $${total.toLocaleString()}`);
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    closeCart();
    displayCartItems();
}

function openSideBar() {
    document.getElementById("sidebar").style.width = "280px";
}

function closeSideBar() {
    document.getElementById("sidebar").style.width = "0";
}

function closeModal() {
    document.getElementById('productModal').classList.remove('active');
}

function showProfile() {
    alert('Blum Siap :P');
}

function logout() {
    alert('Logged out');
}

function showLogin() {
    alert('To be continued^^');
}

function showRegister() {
    alert('Blum connect lgi :P');
}

const visualTrigger = document.querySelector('.profilePic');
const fileInputHook = document.getElementById("ImageSearcher");
const ImageContainer = document.querySelector('.profilePicButton');

// NOTE: This runs instantly the exact millisecond the script file loads up!
const savedSandboxAvatar = localStorage.getItem('sandboxPFP');

if (savedSandboxAvatar !== null) {
    // If an image string exists in storage, force the CSS layout to render it immediately
    ImageContainer.style.backgroundImage = "url('" + savedSandboxAvatar + "')";
    ImageContainer.style.backgroundSize = "cover";
    ImageContainer.style.backgroundPosition = "center";
}


function changePP(){
    fileInputHook.click(); // this opens up the file selecting window NOTE:
}

fileInputHook.addEventListener('change', function(){
    // Select the first item from the internal files array
    const userSelectedFile = this.files[0];
    

    // If a file is successfully loaded, we execute the translation machine because currently userSelectedFile is binary, we need to translate it to URL NOTE::
    if(userSelectedFile){
        //FileReader() is used to translate binary to url IN THIS CASE NOTE:
        const ImageLoader = new FileReader();

        // This internal event handler fires the microsecond the file reading process finishes
        ImageLoader.addEventListener('load', function() {
            // NOTE: The result property contains our image transformed into a massive "Data URL" string
            const finalizedImageString = this.result;

            // DYNAMIC CSS INJECTION: Update our placeholder background on the fly
            ImageContainer.style.backgroundImage = "url('" + finalizedImageString + "')";
            ImageContainer.style.backgroundSize = "cover";
            ImageContainer.style.backgroundPosition = "center";

            // --- THE MISSING CRITICAL LINK ---
            // NOTE: You must explicitly write the data to storage here!
            localStorage.setItem('sandboxPFP', finalizedImageString);
            
        });

        // NOTE: Initialize the tracking engine and tell it to read the asset as a Data URL text string
        ImageLoader.readAsDataURL(userSelectedFile);

    }

});