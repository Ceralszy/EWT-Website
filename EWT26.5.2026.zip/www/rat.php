<?php
$paper[] = "Copier";
$paper[] = "Inkjet";
$paper[] = "Laser";
$paper[] = "Photo";
for ($j = 0; $j<4; ++$j) {
    echo "$paper[$j] <br>";
}
?>