<?php

require '../ewt/db.php'; 
header('Content-Type: application/json');

try {

    $stmt = $conn->query("
        SELECT p.Product_ID as id, p.Name as name, p.Description as description, 
               p.Price as price, c.Category_Name as category, p.Specs as specs,
               p.Stock_Quantity as stock
        FROM PRODUCT p 
        LEFT JOIN CATEGORY c ON p.Category_ID = c.Category_ID
    ");
    
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch(Exception $e) {
    // If it fails, return an empty array so the JavaScript doesn't crash
    echo json_encode([]);
}
?>