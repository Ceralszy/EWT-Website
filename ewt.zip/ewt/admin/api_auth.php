<?php
require '../ewt/db.php';
session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$type = $data['type']; // 'admin' or 'customer'

if ($type === 'admin') {
    $stmt = $conn->prepare("SELECT Staff_ID, Username, Role FROM ADMINS WHERE Username = ? AND Password = ?");
    $stmt->execute([$data['username'], $data['password']]);
} else {
    // Simplified for customer (Add password check here later if needed)
    $stmt = $conn->prepare("SELECT Customer_ID, Username FROM CUSTOMER WHERE Username = ?");
    $stmt->execute([$data['username']]);
}

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $_SESSION['user'] = $user;
    echo json_encode(["success" => true, "data" => $user]);
} else {
    echo json_encode(["success" => false, "error" => "Invalid credentials"]);
}
?>