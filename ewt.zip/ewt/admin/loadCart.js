// load-components.js - ONE FILE to rule them all

function loadHeader() {
    const headerHTML = `
    <div class="header-container">
        <button onclick="openSidebar()" class="menu-btn">☰ Menu</button>
        <div class="logo-center">
            <img src="EwtLogo2.png" alt="EWT Logo">
        </div>
        <a href="javascript:void(0)" onclick="openCart()" class="cart-btn">
            🛒
            <span class="cart-badge" id="cartCount">0</span>
        </a>
    </div>

    <div id="sidebar" class="sidebar">
        <button class="close-btn" onclick="closeSidebar()">&times;</button>
        <a href="index.html">🏠 Home</a>
        <div id="gatedSessionLinks" style="display: none;">
            <a href="#" onclick="filterProducts('all'); closeSidebar();">📦 Products</a>
            <hr>
            <a href="profilePage.html">👤 My Account</a>
            <a href="#" onclick="logout(); closeSidebar();">🚪 Logout</a>
        </div>
        <div id="guestSessionLinks">
            <hr>
            <a href="Login.html">🔑 Login / Register</a>
        </div>
    </div>

    <div id="cartSidebar" class="cart-sidebar">
        <div class="cart-header">
            <h3>My Cart</h3>
            <span class="close-cart" onclick="closeCart()">&times;</span>
        </div>
        <div id="cartItems"></div>
        <div class="cart-total" id="cartTotal"></div>
        <button class="checkout-btn" onclick="proceedToCheckout()">Checkout</button>
    </div>
    `;
    
    document.body.insertAdjacentHTML('afterbegin', headerHTML);
    
    // Header Styles
    const style = document.createElement('style');
    style.textContent = `
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #e2312b;
            padding: 12px 40px;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .menu-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: white;
            padding: 8px 12px;
            border-radius: 8px;
        }
        .menu-btn:hover { background: rgba(255,255,255,0.15); }
        .logo-center { display: flex; align-items: center; gap: 12px; }
        .logo-center img { height: 50px; width: auto; }
        .logo-text { color: white; font-size: 18px; font-weight: 600; letter-spacing: 1px; }
        .cart-btn { color: white; text-decoration: none; font-size: 22px; padding: 8px 12px; border-radius: 8px; position: relative; display: flex; align-items: center; }
        .cart-btn:hover { background: rgba(255,255,255,0.15); }
        .cart-badge { position: absolute; top: -5px; right: -5px; background-color: #ffc107; color: #333; font-size: 11px; font-weight: bold; padding: 2px 6px; border-radius: 50%; min-width: 18px; text-align: center; }
        .sidebar { height: 100%; width: 0; position: fixed; top: 0; left: 0; background-color: #800020; overflow-x: hidden; transition: 0.3s; padding-top: 60px; z-index: 1000; }
        .sidebar .close-btn { position: absolute; top: 10px; right: 20px; font-size: 32px; background: none; border: none; color: white; cursor: pointer; }
        .sidebar a { padding: 14px 25px; text-decoration: none; font-size: 18px; color: white; display: block; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar a:hover { background-color: #e2312b; padding-left: 35px; }
        .sidebar hr { margin: 10px; border-color: #555; }
        .cart-sidebar { position: fixed; right: -400px; top: 0; width: 400px; height: 100%; background: white; box-shadow: -4px 0 15px rgba(0,0,0,0.15); transition: 0.3s; padding: 25px; z-index: 1000; overflow-y: auto; }
        .cart-sidebar.open { right: 0; }
        .cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #eee; }
        .close-cart { cursor: pointer; font-size: 28px; color: #999; }
        .cart-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #eee; }
        .cart-total { font-size: 20px; font-weight: bold; text-align: right; margin-top: 20px; padding-top: 15px; border-top: 2px solid #ddd; }
        .checkout-btn { background: #27ae60; color: white; border: none; padding: 14px; width: 100%; border-radius: 8px; margin-top: 20px; cursor: pointer; font-size: 16px; font-weight: bold; }
        .checkout-btn:hover { background: #219a52; }
        @media (max-width: 768px) { .logo-text { display: none; } .cart-sidebar { width: 100%; right: -100%; } }
    `;
    document.head.appendChild(style);
    
    // Initialize all functions
    window.openSidebar = function() { document.getElementById("sidebar").style.width = "280px"; };
    window.closeSidebar = function() { document.getElementById("sidebar").style.width = "0"; };
    window.openCart = function() { displayCartItems(); document.getElementById("cartSidebar").classList.add("open"); };
    window.closeCart = function() { document.getElementById("cartSidebar").classList.remove("open"); };
    window.proceedToCheckout = function() { window.location.href = 'cart.html'; };
    
    window.updateCartCount = function() {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let total = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
        let badge = document.getElementById('cartCount');
        if(badge) badge.textContent = total;
    };
    
    window.displayCartItems = function() {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let cartDiv = document.getElementById('cartItems');
        let totalDiv = document.getElementById('cartTotal');
        if(!cartDiv) return;
        if(cart.length === 0) {
            cartDiv.innerHTML = '<p style="text-align:center; color:#999; padding:20px;">Your cart is empty</p>';
            if(totalDiv) totalDiv.innerHTML = '';
            return;
        }
        let total = 0;
        cartDiv.innerHTML = cart.map((item, idx) => {
            let subtotal = item.price * item.quantity;
            total += subtotal;
            return `<div class="cart-item"><div><strong>${item.name}</strong><br>RM ${item.price} x ${item.quantity}</div><div>RM ${subtotal.toLocaleString()}<button onclick="removeFromCart(${idx})" style="background:#e2312b; color:white; border:none; padding:5px 10px; margin-left:10px; cursor:pointer; border-radius:5px;">×</button></div></div>`;
        }).join('');
        if(totalDiv) totalDiv.innerHTML = `Total: RM ${total.toLocaleString()}`;
    };
    
    window.removeFromCart = function(idx) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        cart.splice(idx, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        displayCartItems();
    };
    
    window.checkLoginStatus = function() {
        let isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
        let gated = document.getElementById('gatedSessionLinks');
        let guest = document.getElementById('guestSessionLinks');
        if(gated && guest) {
            gated.style.display = isLoggedIn ? 'block' : 'none';
            guest.style.display = isLoggedIn ? 'none' : 'block';
        }
    };
    
    window.logout = function() {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('savedUsername');
        localStorage.removeItem('savedEmail');
        alert('Logged out successfully!');
        window.location.reload();
    };
    
    updateCartCount();
    checkLoginStatus();
    
    window.addEventListener('storage', function(e) {
        if(e.key === 'cart') { updateCartCount(); if(document.getElementById('cartSidebar')?.classList.contains('open')) displayCartItems(); }
        if(e.key === 'isLoggedIn') checkLoginStatus();
    });
}

// Load when page is ready
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', loadHeader);
else loadHeader();