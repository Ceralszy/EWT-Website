<?php
require '../ewt/db.php';
$data = json_decode(file_get_contents("php://input"), true);

$id = $data['id'];
$action = $data['action'];

try {
    if ($action === 'update') {
        // Update Order Status
        $stmt = $conn->prepare("UPDATE ORDERS SET Fulfillment_Method = ? WHERE Order_ID = ?");
        $stmt->execute([$data['status'], $id]);
        
        // Update Payment Status
        $stmtPay = $conn->prepare("UPDATE PAYMENT SET Payment_Status = ? WHERE Payment_ID = (SELECT Payment_ID FROM ORDERS WHERE Order_ID = ?)");
        $stmtPay->execute([$data['payment'], $id]);
    } 
    elseif ($action === 'delete') {
        // Delete Order (Cascades due to your DB setup)
        $stmt = $conn->prepare("DELETE FROM ORDERS WHERE Order_ID = ?");
        $stmt->execute([$id]);
    }
    echo json_encode(["success" => true]);
} catch(Exception $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>