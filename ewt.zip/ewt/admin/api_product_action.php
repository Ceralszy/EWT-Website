<?php
require '../ewt/db.php'; 
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'] ?? '';

try {
    if ($action === 'add') {
        $stmt = $conn->prepare("INSERT INTO PRODUCT (Name, Price, Stock_Quantity, Category_ID) VALUES (?, ?, ?, (SELECT Category_ID FROM CATEGORY WHERE Category_Name = ? LIMIT 1))");
        $stmt->execute([$data['name'], $data['price'], $data['stock'], $data['category']]);
        
        echo json_encode(["success" => true, "id" => $conn->lastInsertId()]);
    } 
    elseif ($action === 'update_stock') {
        $stmt = $conn->prepare("UPDATE PRODUCT SET Stock_Quantity = ? WHERE Product_ID = ?");
        $stmt->execute([$data['stock'], $data['id']]);
        echo json_encode(["success" => true]);
    }
    elseif ($action === 'delete') {
        $stmt = $conn->prepare("DELETE FROM PRODUCT WHERE Product_ID = ?");
        $stmt->execute([$data['id']]);
        echo json_encode(["success" => true]);
    }
} catch(Exception $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>