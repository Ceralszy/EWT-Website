<?php
require '../ewt/db.php';
$data = json_decode(file_get_contents("php://input"), true);

try {
    // Your ADMINS schema: Username, Password, Position, Role
    $stmt = $conn->prepare("INSERT INTO ADMINS (Username, Password, Position, Role) VALUES (?, ?, ?, ?)");
    
    $stmt->execute([
        $data['username'], 
        $data['password'], 
        $data['department'], 
        $data['role']
    ]);
    
    echo json_encode(["success" => true]);
} catch(Exception $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>