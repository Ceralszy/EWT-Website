<?php
require '../ewt/db.php';
header('Content-Type: application/json');

// Fetch orders with customer names and payment status
$stmt = $conn->query("
    SELECT 
        o.Order_ID as id, 
        COALESCE(c.Username, 'Guest') as customer, 
        o.Order_Date as date, 
        o.Total_Price as amount, 
        o.Fulfillment_Method as status, 
        COALESCE(p.Payment_Status, 'Pending') as paymentStatus
    FROM ORDERS o
    LEFT JOIN CUSTOMER c ON o.Customer_ID = c.Customer_ID
    LEFT JOIN PAYMENT p ON o.Payment_ID = p.Payment_ID
    ORDER BY o.Order_Date DESC
");

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>