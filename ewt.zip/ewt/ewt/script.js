let products = [];
let currentProducts = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];

async function loadDatabaseProducts() {
    try {
        const res = await fetch('api_products.php');
        const dbData = await res.json();
        const localImages = JSON.parse(localStorage.getItem('saved_product_images')) || {};

        products = dbData.map(p => ({
            ...p,
            category: (p.category || '').toLowerCase(),
            oldPrice: p.price * 1.1, 
            image: localImages[p.id] || "https://via.placeholder.com/500" // LocalStorage image fallback
        }));

        currentProducts = [...products];
        renderProducts();
    } catch (error) {
        console.error("Database fetch error:", error);
    }
}

function renderProducts() {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    currentProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.onclick = () => showProductDetail(product);
        
        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <div class="product-info">
                <div class="product-name">${product.name}</div>
                <div class="product-price">
                    RM ${parseFloat(product.price).toLocaleString()}
                    <span class="old-price">RM ${parseFloat(product.oldPrice).toLocaleString()}</span>
                </div>
                <button class="add-btn" onclick="event.stopPropagation(); addToCart(${product.id})">Add to Cart</button>
            </div>
        `;
        
        grid.appendChild(card);
    });
}

function filterProducts(category) {
    if (category === 'all') {
        currentProducts = [...products];
    } else {
        currentProducts = products.filter(p => p.category === category);
    }
    renderProducts();
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existing = cart.find(item => item.id === productId);
    
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    displayCartItems(); 
    alert(`${product.name} added to cart!`);
}

function updateCartCount() {
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountElem = document.getElementById('cartCount');
    if (cartCountElem) cartCountElem.textContent = total;
}

function openSidebar() {
    document.getElementById("sidebar").style.width = "280px"; 
    document.getElementById("sidebar").classList.add('open');
    document.getElementById("sidebar").classList.remove('closed');
}

function closeSidebar() {
    document.getElementById("sidebar").style.width = "0"; 
    document.getElementById("sidebar").classList.add('closed');
    document.getElementById("sidebar").classList.remove('open');
}

function openCart() {
    displayCartItems();
    document.getElementById('cartSidebar').classList.add('open');
}

function closeCart() {
    document.getElementById('cartSidebar').classList.remove('open');
}

function displayCartItems() {
    const cartDiv = document.getElementById('cartItems');
    const totalDiv = document.getElementById('cartTotal');
    const checkoutBtn = document.querySelector('.checkout-btn');
    
    if (cart.length === 0) {
        cartDiv.innerHTML = '<p style="text-align:center; margin-top:20px;">Your cart is empty</p>';
        totalDiv.innerHTML = '';
        if (checkoutBtn) checkoutBtn.style.display = 'none';
        return;
    }
    
    if (checkoutBtn) checkoutBtn.style.display = 'block';
    
    let total = 0;
    cartDiv.innerHTML = cart.map((item, index) => {
        const subtotal = item.price * item.quantity;
        total += subtotal;
        return `
            <div class="cart-item">
                <div>
                    <strong>${item.name}</strong><br>
                    RM ${parseFloat(item.price).toLocaleString()} x ${item.quantity}
                </div>
                <div>
                    RM ${subtotal.toLocaleString()}
                    <button onclick="removeFromCart(${index})" style="background:#e2312b; color:white; border:none; padding:5px 10px; margin-left:10px; cursor:pointer;">×</button>
                </div>
            </div>
        `;
    }).join('');
    
    totalDiv.innerHTML = `Total: RM ${total.toLocaleString()}`;
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    displayCartItems();
}

function checkout() {
    if (cart.length === 0) return;
    window.location.href = 'cart.html';
}

function showProductDetail(product) {
    const modal = document.getElementById('productModal');
    // Create the modal element if it doesn't exist in the HTML yet
    if (!modal) {
        const modalHtml = `
        <div id="productModal" class="modal">
            <div class="modal-content">
                <span class="close-modal" onclick="closeModal()">&times;</span>
                <div id="modalContent"></div>
            </div>
        </div>`;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }
    
    const activeModal = document.getElementById('productModal');
    const modalContent = document.getElementById('modalContent');
    
    modalContent.innerHTML = `
        <h2>${product.name}</h2>
        <img src="${product.image}" style="width:100%; border-radius:10px; margin:15px 0;">
        <p class="desc-text">${product.description}</p>
        <div class="specs-container">
            <strong>Specs:</strong> 
            <span>${product.specs}</span>
        </div>
        <div class="product-price" style="margin:15px 0;">
            RM ${parseFloat(product.price).toLocaleString()}
            <span class="old-price">RM ${parseFloat(product.oldPrice).toLocaleString()}</span>
        </div>
        <button class="add-btn" onclick="addToCart(${product.id}); closeModal();">Add to Cart</button>
    `;
    
    activeModal.classList.add('active');
}

function closeModal() {
    const modal = document.getElementById('productModal');
    if (modal) modal.classList.remove('active');
}

// Start the app!
loadDatabaseProducts();
updateCartCount();