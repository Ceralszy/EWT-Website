<?php
require 'db.php';
header('Content-Type: application/json');

$stmt = $conn->query("
    SELECT p.Product_ID as id, p.Name as name, p.Description as description, 
           p.Price as price, c.Category_Name as category, p.Specs as specs
    FROM PRODUCT p JOIN CATEGORY c ON p.Category_ID = c.Category_ID
");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>