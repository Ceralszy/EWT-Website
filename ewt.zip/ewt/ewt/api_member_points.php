<?php
require 'db.php';
header('Content-Type: application/json');

$customerId = $_GET['id'] ?? null;

if (!$customerId) {
    echo json_encode(["error" => "No ID provided"]);
    exit;
}

try {
    // Fetch just the points for this specific member matching your schema
    $stmt = $conn->prepare("SELECT Point FROM MEMBERS WHERE Customer_ID = ?");
    $stmt->execute([$customerId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Return it as "Points" so your JavaScript still reads it perfectly
    echo json_encode(["Points" => $result['Point'] ?? 0]);
} catch(Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>