<?php
require 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

try {
    $conn->beginTransaction();

    $method = $data['method'] ?? 'Delivery';
    $address = $data['address'] ?? 'No Address Provided';
    $customerId = $data['customer_id'] ?? null; 
    $pointsUsed = intval($data['points_used'] ?? 0); // Read points used from payload

    // 1. Create the Order base row
    $stmt = $conn->prepare("INSERT INTO ORDERS (Customer_ID, Fulfillment_Method, Shipping_Address) VALUES (?, ?, ?)");
    $stmt->execute([$customerId, $method, $address]);
    $orderId = $conn->lastInsertId();

    // 2. Add Items to Order Details
    if(isset($data['cart']) && is_array($data['cart'])) {
        $stmtItem = $conn->prepare("INSERT INTO ORDER_DETAIL (Order_ID, Product_ID, Quantity, Unit_Price) VALUES (?, ?, ?, ?)");
        foreach($data['cart'] as $item) {
            $stmtItem->execute([$orderId, $item['id'], $item['quantity'], $item['price']]);
        }
    }

    // 3. Generate the standard Invoice & Payment totals
    $conn->exec("CALL FinalizeCheckout($orderId)");

    // 4. NEW: Apply Point Reductions if used!
    if ($pointsUsed >= 10 && $customerId) {
        $discountAmount = $pointsUsed / 10; // RM1 per 10 points

        // Deduct discount from the Order Total
        $stmtDedOrder = $conn->prepare("UPDATE ORDERS SET Total_Price = GREATEST(Total_Price - ?, 0.00) WHERE Order_ID = ?");
        $stmtDedOrder->execute([$discountAmount, $orderId]);

        // Deduct discount from the Linked Payment Row Invoice Amount
        $stmtDedPay = $conn->prepare("UPDATE PAYMENT p, ORDERS o SET p.Total_Amount = GREATEST(p.Total_Amount - ?, 0.00) WHERE p.Payment_ID = o.Payment_ID AND o.Order_ID = ?");
        $stmtDedPay->execute([$discountAmount, $orderId]);

        // Take points away from their balance in MEMBERS table
        $stmtDedPoints = $conn->prepare("UPDATE MEMBERS SET Point = GREATEST(Point - ?, 0) WHERE Customer_ID = ?");
        $stmtDedPoints->execute([$pointsUsed, $customerId]);
    }

    // 5. Award new EWT Points based on the new final total!
    if ($customerId) {
        $conn->exec("CALL Award_Points($orderId)");
    }

    $conn->commit();
    echo json_encode(["success" => true, "order_id" => $orderId]);

} catch(Exception $e) {
    $conn->rollBack();
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>