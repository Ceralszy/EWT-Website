<?php
require 'db.php';
$data = json_decode(file_get_contents("php://input"), true);

$conn->beginTransaction();
try {
    // 1. Create the Custom Build record
    $stmt = $conn->prepare("INSERT INTO CUSTOM_BUILD (Build_Name) VALUES (?)");
    $stmt->execute([$data['customer_name'] . "'s PC"]);
    $buildId = $conn->lastInsertId();

    // 2. Loop through selected parts and trigger your Stored Procedure
    $stmtPart = $conn->prepare("CALL AddPartToBuild(?, ?)");
    foreach($data['part_ids'] as $partId) {
        if (!empty($partId)) {
            $stmtPart->execute([$buildId, $partId]);
        }
    }

    $conn->commit();
    echo json_encode(["success" => true, "build_id" => $buildId]);
} catch(Exception $e) {
    $conn->rollBack();
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>