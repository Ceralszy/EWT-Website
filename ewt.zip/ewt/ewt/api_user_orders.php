<?php
require 'db.php';
header('Content-Type: application/json');

$customerId = $_GET['id'] ?? null;

if (!$customerId) {
    echo json_encode([]);
    exit;
}

try {
    // Fetch orders and join with the PAYMENT table to get the live status
    $stmt = $conn->prepare("
        SELECT o.Order_ID, o.Order_Date, o.Total_Price, o.Fulfillment_Method, p.Payment_Status 
        FROM ORDERS o
        LEFT JOIN PAYMENT p ON o.Payment_ID = p.Payment_ID
        WHERE o.Customer_ID = ?
        ORDER BY o.Order_Date DESC
    ");
    $stmt->execute([$customerId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch(Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>